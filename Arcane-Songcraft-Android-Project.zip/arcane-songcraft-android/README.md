# Arcane Songcraft — Android APK project

This Android WebView wrapper packages the supplied Song Concept Builder & Randomizer HTML as an installable Android app. It retains the original HTML/JavaScript application, including its local saved-concept vault.

## Build an APK

1. Open this folder as a project in Android Studio (JDK 17 and Android SDK 35 required), then build **app > Build > Build APK(s)**.
2. Or push this folder to a GitHub repository. The included GitHub Actions workflow builds a debug APK on each push to `main` and lets you download it from the workflow run's **Artifacts** section.

The app needs internet access for the original page's Tailwind, Lucide, and Google Fonts CDN resources. Saved concepts use the WebView's local storage on the device.
